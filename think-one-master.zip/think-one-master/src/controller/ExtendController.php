<?php

namespace think\one\controller;

class ExtendController extends BaseController
{

    public function index()
    {
        return $this->fetch();
    }

}
