<?php

return [
    'think_one_version' => '1.0',

    'log' => [
        // 日志记录方式，内置 file socket 支持扩展
        'type' => 'Test',
    ],
];
