<?php
include __DIR__ . '/../vendor/autoload.php';

include __DIR__ . '/../vendor/topthink/framework/base.php';

